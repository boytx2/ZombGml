
image_angle = point_direction(x,y,oPlayer.x,oPlayer.y)


hsp = lengthdir_x(walksp, image_angle);
vsp = lengthdir_y(walksp, image_angle);


x += hsp;
y += vsp;


if (place_meeting(x+hsp, y+vsp, oBullet)) //takes 1 hp away when bullet hits zombie
{
	hp -=1
	instance_destroy(oBullet)
}
if (hp <=0)// kills zombie if 0hp
{
	instance_create_layer(x,y,"instances",oAmmo)
	instance_destroy()
}