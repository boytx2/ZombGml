if (place_meeting(x,y, oPlayer))//checks if player walks on ammo, if so gives him 6 ammo
{
	oBlick.ammo +=6
	instance_destroy()
}