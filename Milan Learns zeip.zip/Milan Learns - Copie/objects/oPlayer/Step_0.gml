

//Get Player input
key_left = keyboard_check(ord("A")) ;
key_right = keyboard_check(ord("D")) ;
key_up = keyboard_check(ord("W")) ;
key_down = keyboard_check(ord("S")) ;

//Calculate movement
var hMove = key_right - key_left;

var vMove = key_down - key_up;

hsp = hMove * walksp;

vsp = vMove * walksp;

// horizontal
if (hit_wall(x + hsp, y))
{
    while (!hit_wall(x + sign(hsp), y)) x += sign(hsp);
    hsp = 0;
}
x += hsp;

// vertical
if (hit_wall(x, y + vsp))
{
    while (!hit_wall(x, y + sign(vsp))) y += sign(vsp);
    vsp = 0;
}
y += vsp;


zombiex = random (768)// finds random coordinates for the zombie to spawn
zombiey = random (768)
if (alarm [1] < 0)
{
	instance_create_layer(zombiex,zombiey,"instances",oZombie) //spawns the zombies 
	alarm [1] = 300
}


var mx = mouse_x;
var my = mouse_y;
aim_dir = point_direction(x,y,mx,my)
if (aim_dir >= 330 || aim_dir < 30)  image_index = 0; 
else if (aim_dir < 50)               image_index = 2;
else if (aim_dir < 80)               image_index = 4;
else if (aim_dir < 110)              image_index = 6; 
else if (aim_dir < 140)              image_index = 5;
else if (aim_dir < 160)              image_index = 3;
else if (aim_dir < 210)              image_index = 1; 
else if (aim_dir < 250)              image_index = 8;
else if (aim_dir < 260)              image_index = 10;
else if (aim_dir < 280)              image_index = 11; 
else if (aim_dir < 290)              image_index = 9;
else                                 image_index = 7;

