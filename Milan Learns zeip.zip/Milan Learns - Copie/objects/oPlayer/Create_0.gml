hsp = 0;
vsp = 0;
walksp = 4;

mask_body = sPlayer;        // your head/body sprite
mask_legs = sLegsplayer;    // your legs sprite

hit_wall = function(_x, _y)
{
    var hit = false;

    mask_index = mask_body;
    if (place_meeting(_x, _y, oWall)) hit = true;

    mask_index = mask_legs;
    if (place_meeting(_x, _y, oWall)) hit = true;

    mask_index = mask_body;   // restore, so zombies and bullets still use the body
    return hit;
}
