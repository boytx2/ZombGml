x = oPlayer.x
y = oPlayer.y

ammo = 5
ammocolor = c_white
