
shoot = mouse_check_button(mb_left)

var mx = mouse_x;
var my = mouse_y;

image_angle = point_direction(x,y,mx,my)


if (shoot && alarm[0]<=0 && ammo >0)
{
	instance_create_layer(x,y,"instances",oBullet)
	ammo -=1
	alarm[0] = 20
}


if (ammo <= 2) // just turns the ammo red or white depending on how much is left
{
	ammocolor = c_red
}
else 
{
	ammocolor = c_white
}
