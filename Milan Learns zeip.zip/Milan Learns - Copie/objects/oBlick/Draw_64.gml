draw_set_font(fntAmmo);
draw_set_halign(fa_right);
draw_set_valign(fa_top);
draw_set_color(ammocolor);

draw_text(display_get_gui_width() - 600, 650, "Ammo: " + string(ammo));// draws how much ammo

// reset so other text isn't affected
draw_set_halign(fa_left);
draw_set_color(c_white);
draw_set_font(-1);   // back to the default font