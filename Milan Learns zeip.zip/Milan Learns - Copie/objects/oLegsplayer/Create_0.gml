image_speed = 0;       // we animate manually
anim = 0;              // position inside the current animation
last_dir = "still";

spd_side = 0.25;       // left/right animation speed
spd_vert = 0.12;       // up/down animation speed
