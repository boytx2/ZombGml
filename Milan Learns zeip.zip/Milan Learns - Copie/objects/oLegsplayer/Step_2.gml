x = oPlayer.x;
y = oPlayer.y;

var hMove = oPlayer.key_right - oPlayer.key_left;
var vMove = oPlayer.key_down - oPlayer.key_up;

var dir = "still";
var first = 0;
var count = 1;
var spd = 0;

if (hMove != 0)
{
    // left/right wins if both axes are pressed
    if (hMove > 0) { dir = "right"; first = 1; count = 5; }
    else           { dir = "left";  first = 6; count = 5; }
    spd = spd_side;
}
else if (vMove != 0)
{
    if (vMove < 0) { dir = "up";   first = 11; count = 2; }
    else           { dir = "down"; first = 13; count = 2; }
    spd = spd_vert;
}

// restart the cycle when the direction changes
if (dir != last_dir) { anim = 0; last_dir = dir; }

if (dir == "still")
{
    image_index = 0;
}
else
{
    anim += spd;
    if (anim >= count) anim -= count;   // loop
    image_index = first + floor(anim);
}