veloc = 5

direction = oBlick.image_angle


