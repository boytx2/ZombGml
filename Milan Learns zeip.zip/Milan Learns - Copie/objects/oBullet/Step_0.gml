
hsp = lengthdir_x(veloc, direction);
vsp = lengthdir_y(veloc, direction);


x += hsp;
y += vsp;



if (place_meeting(x+hsp, y+vsp, oWall))
{
	while(!place_meeting(x+sign(hsp),y+sign(vsp),oWall))
	{
		x = x + sign(hsp);
		y = y + sign(vsp);
	}
	
	instance_destroy()
}
