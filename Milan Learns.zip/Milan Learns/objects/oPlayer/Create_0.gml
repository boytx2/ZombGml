hsp = 0;
vsp = 0;
walksp = 4;

mask_body = sPlayer;        // your head/body sprite
mask_legs = sLegsplayer;    // your legs sprite

radflag = true //radiusflag, good vqlue
damage = 1 // multiplied by gun or bullet type
hit_wall = function(_x, _y)
{
    var hit = false;

    mask_index = mask_body;
    if (place_meeting(_x, _y, oWall)) hit = true;

    mask_index = mask_legs;
    if (place_meeting(_x, _y, oWall)) hit = true;

    mask_index = mask_body;   // restore, so zombies and bullets still use the body
    return hit;
}


// Set how zoomed in you want to be
zoom = 1.5; // 1 = normal, 2 = twice as close, 0.5 = zoomed out

base_w = 768;  // your base view/resolution width
base_h = 768;  // your base view/resolution height

cam = view_camera[0];
camera_set_view_size(cam, base_w / zoom, base_h / zoom);