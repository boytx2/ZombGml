var view_w = camera_get_view_width(cam);
var view_h = camera_get_view_height(cam);

var target_x = x - view_w / 2;
var target_y = y - view_h / 2;

// Keep the camera inside the room
target_x = clamp(target_x, 0, room_width - view_w);
target_y = clamp(target_y, 0, room_height - view_h);

camera_set_view_pos(cam, target_x, target_y);
