veloc = 5
damage = 3
oPlayer.damage = oPlayer.damage*damage

direction = oBlick.image_angle

var mx = mouse_x;
var my = mouse_y;

image_angle = point_direction(x,y,mx,my)
